import React from 'react'

const SidebarItem = props => {

    const active = props.active ? 'active' : ''

    return (
        <>
                {localStorage.getItem('Access')=='Cashier' && (props.title=='Dashboard') &&(<div className="sidebar__item">
                <div className={`sidebar__item-inner ${active}`}>
                    <i className={props.icon}></i>
                    <span>
                        {props.title}
                    </span>
                </div>
                </div>)}
        </>
    )
}

export default SidebarItem
